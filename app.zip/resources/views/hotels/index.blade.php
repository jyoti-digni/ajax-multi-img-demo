@extends('layouts.app')

@section('content')
    <div class="container mt-5">
        <form action="" id="submitHotelForm">
            <!-- Hotel Name Input -->
            <div class="mb-3">
                <label for="name" class="form-label">Hotel Name</label>
                <input type="text" class="form-control" id="name" name="name" placeholder="Hotel Name" required>
            </div>

            <!-- Hotel Description Input -->
            <div class="mb-3">
                <label for="description" class="form-label">Hotel Description</label>
                <textarea class="form-control" name="description" id="description" rows="5" placeholder="Hotel Description"
                    required></textarea>
            </div>

            <!-- Location Section -->
            <div id="location-wrapper" class="mb-3">
                <label class="form-label">Location</label>
                <div class="location d-flex align-items-center mb-2">
                    <input type="text" class="form-control me-2" name="locations[0][latitude]" placeholder="Latitude">
                    <input type="text" class="form-control me-2" name="locations[0][longitude]" placeholder="Longitude">
                    <button type="button" class="btn btn-danger remove-location">Remove</button>
                </div>
            </div>


            <div class="d-flex mb-3">
                <button type="button" class="btn btn-primary me-2" id="add-location">Add Location</button>
                <button type="submit" class="btn btn-success">Submit</button>
            </div>
        </form>


        <div class="table">
            <table class="table mt-3">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Location Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="hotelTable">
                    <!-- Product rows will be populated by JavaScript -->
                    @foreach ($hotels as $hotel)
                        <tr>
                            <td>{{ $hotel->name }}</td>
                            <td>{{ $hotel->description }}</td>
                            <td>
                                @foreach ($hotel->locations as $location)
                                    <div>
                                        <span>Latitude: {{ $location->latitude }}</span>
                                        <span>Longitude: {{ $location->longitude }}</span>
                                        <span>Location Name: {{ $location->address }}</span>
                                    </div>
                                @endforeach

                            </td>
                            <td>
                               <a href="{{ url('/hotel-view', $hotel->id) }}">View Details</a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection

@section('script')
    <script>
        $(document).ready(function() {
            let locationIndex = 1;
            $('#add-location').click(function() {
                $('#location-wrapper').append(
                    `<div class="location d-flex align-items-center mb-2">
                    <input type="text" class="form-control me-2" name="locations[${locationIndex}][latitude]" placeholder="Latitude">
                    <input type="text" class="form-control me-2" name="locations[${locationIndex}][longitude]" placeholder="Longitude">
                    <button type="button" class="btn btn-danger remove-location">Remove</button>
                </div>`
                );
                locationIndex++;
            })

            $(document).on('click', '.remove-location', function() {
                $(this).closest('.location').remove();
            });

            $('#submitHotelForm').submit(function(e) {
                e.preventDefault();
                let formData = $(this).serialize();
                $.ajax({
                    url: '/hotel-store',
                    method: 'POST',
                    data: formData,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        console.log(response.data, 'ResponseData::');

                        const hotel = response.data.hotel
                        const locations = response.data.locations

                        $('#hotelTable').append(`<tr>
                            <td>${hotel.name}</td>
                            <td>${hotel.description}</td>
                            <td>${locations.map(location => ` <div>
                                <span>Latitude: ${location.latitude}</span>
                                <span>Longitude: ${location.longitude}</span>
                                <span>Location Name: ${location.address}</span>
                                </div>`).join('')}</td>
                            <td>
                                <button class="btn btn-info" onclick="editProduct(${hotel.id})">Edit</button>
                                <button class="btn btn-danger" onclick="deleteProduct(${hotel.id})">Delete</button>
                            </td>
                        </tr>`)
                        alert(response.success);
                    },
                    error: function(error) {
                        console.log(error);
                    }
                });

            })

        })
    </script>
@endsection
