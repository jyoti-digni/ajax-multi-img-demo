@extends('layouts.app')

@section('content')
    <div class="container mt-5">
        <h2>{{ $hotel->name }} - Location Details</h2>

        <div id="map" style="height: 500px; width: 100%;"></div> <!-- Map will be displayed here -->

        <table class="table mt-5">
            <thead>
                <tr>
                    <th>Location</th>
                    <th>Coordinates</th>
                    <th>Address</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($hotel->locations as $location)
                    <tr>
                        <td>Location {{ $loop->iteration }}</td>
                        <td>
                            Latitude: {{ $location->latitude }}<br>
                            Longitude: {{ $location->longitude }}
                        </td>
                        <td>{{ $location->address }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection

@section('script')
    <!-- Include Leaflet.js -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Map is being initialized');

            var locations = @json($hotel->locations);
            console.log(locations, 'Locations');

            // Filter out locations that don't have valid latitude and longitude
            var validLocations = locations.filter(function(location) {
                return location.latitude && location.longitude;
            });

            // Check if there are valid locations to display
            if (validLocations.length > 0) {
                // Create a LatLngBounds object to include all valid locations
                var bounds = L.latLngBounds(validLocations.map(function(location) {
                    return [location.latitude, location.longitude];
                }));

                // Initialize the map but don't set a static view
                var map = L.map('map');

                // Fit the map to the bounds of all valid locations
                map.fitBounds(bounds);

                // Add OpenStreetMap tiles
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '© OpenStreetMap contributors'
                }).addTo(map);

                // Add markers for each valid location
                validLocations.forEach(function(location) {
                    var marker = L.marker([location.latitude, location.longitude]).addTo(map)
                        .bindPopup("<strong>{{ $hotel->name }}</strong><br>" + location.address);

                    // Optionally, automatically open the pop-up for the first location
                    if (location === validLocations[0]) {
                        marker.openPopup();
                    }
                });
            } else {
                console.log("No valid locations found for this hotel");
            }
        });
    </script>
@endsection
