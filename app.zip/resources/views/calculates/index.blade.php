@extends('layouts.app')

@section('content')
    <form action="{{ url('/calculate-distance') }}" method="GET">
        <label for="origin">Origin:</label>
        <input type="text" name="origin" required>

        <label for="destination">Destination:</label>
        <input type="text" name="destination" required>

        <button type="submit">Calculate Distance</button>
    </form>

    @if (isset($distanceData))
        <div class="container">
            <p><strong>Distance:</strong> {{ $distanceData['distance'] ?? 'Not available' }} km</p>
            <span><strong>Duration:</strong> {{ $distanceData['duration'] ?? 'Not available' }} minutes</span>
        </div>
    @endif
@endsection
