@extends('layouts.app')

@section('content')
    {{-- <form action="{{ url('payment') }}" id="payment-form" method="POST">
        @csrf

        <script
            src="https://checkout.stripe.com/checkout.js" class="stripe-button"
            data-key="{{ env('STRIPE_KEY') }}"
            data-amount="5000" 
            data-name="Practice Payment"
            data-description="Test payment for practice"
            data-currency="usd">
        </script>
    </form> --}}

    <h2>Stripe Checkout</h2>

    <form id="payment-form">
        <div id="card-element" class="StripeElement"></div>
        <button id="submit">Pay</button>
        <div id="card-errors" role="alert"></div>
    </form>
@endsection


@Section('script')
    <script src="https://js.stripe.com/v3/"></script>

    <script>
        // Initialize Stripe
        var stripe = Stripe('{{ config('services.stripe.key') }}');
        var elements = stripe.elements();

        // Create an instance of the card Element.
        var card = elements.create('card');
        card.mount('#card-element');

        // Handle real-time validation errors from the card Element.
        card.on('change', function(event) {
            var displayError = document.getElementById('card-errors');
            if (event.error) {
                displayError.textContent = event.error.message;
            } else {
                displayError.textContent = '';
            }
        });

        // Handle form submission
        var form = document.getElementById('payment-form');
        form.addEventListener('submit', function(event) {
            event.preventDefault();

            // Create a Payment Method
            stripe.createPaymentMethod({
                type: 'card',
                card: card,
            }).then(function(result) {
                if (result.error) {
                    // Display error.message in #card-errors
                    var errorElement = document.getElementById('card-errors');
                    errorElement.textContent = result.error.message;
                } else {
                    // Send payment method ID to your server
                    fetch('{{ url('payment') }}', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        },
                        body: JSON.stringify({
                            payment_method_id: result.paymentMethod.id,
                        }),
                    }).then(function(response) {
                        return response.json();
                    }).then(function(data) {
                        // Confirm the PaymentIntent using the client_secret
                        stripe.confirmCardPayment(data.client_secret, {
                            payment_method: result.paymentMethod.id,
                        }).then(function(result) {
                            if (result.error) {
                                // Show error to your customer (e.g., insufficient funds)
                                var errorElement = document.getElementById('card-errors');
                                errorElement.textContent = result.error.message;
                            } else {
                                // The payment has been processed!
                                if (result.paymentIntent.status === 'succeeded') {
                                    window.location.href = '{{ url('success') }}';
                                }
                            }
                        });
                    });
                }
            });
        });
    </script>
@endsection
