@extends('layouts.app')

@section('content')
    <h1>Time Entries</h1>
    
    <!-- Start Timer Button -->
    <form action="{{ route('time_entries.start') }}" method="POST">
        @csrf
        <button type="submit">Start Timer</button>
    </form>

    <h2>Your Time Entries</h2>
    <ul>
        @foreach($timeEntries as $entry)
            <li>
                Start: {{ $entry->start_time }}
                @if($entry->end_time)
                    - End: {{ $entry->end_time }} - Duration: {{ $entry->duration }}
                @else
                    - <form action="{{ route('time_entries.stop', $entry->id) }}" method="POST" style="display:inline;">
                        @csrf
                        @method('PUT')
                        <button type="submit">Stop Timer</button>
                    </form>
                    <span id="counter-{{ $entry->id }}" data-start="{{ $entry->start_time }}" data-end="{{ now() }}"></span>
                @endif
            </li>
        @endforeach
    </ul>

   
@endsection

@section('script')
<script>
    document.addEventListener('DOMContentLoaded', function () {
        @foreach($timeEntries as $entry)
            if (!document.querySelector(`#counter-{{ $entry->id }}`).innerText) {
                startCounter('{{ $entry->id }}', document.querySelector(`#counter-{{ $entry->id }}`).dataset.start, document.querySelector(`#counter-{{ $entry->id }}`).dataset.end);
            }
        @endforeach
    });

    function startCounter(elementId, startTime, endTime) {
        const startTimeMs = new Date(startTime).getTime();
        const endTimeMs = endTime ? new Date(endTime).getTime() : null;

        function updateCounter() {
            const now = new Date().getTime();
            const elapsed = endTimeMs ? endTimeMs - startTimeMs : now - startTimeMs;

            document.getElementById(`counter-${elementId}`).innerText = formatTime(elapsed);
        }

        function formatTime(milliseconds) {
            const seconds = Math.floor(milliseconds / 1000);
            const hours = Math.floor(seconds / 3600);
            const minutes = Math.floor((seconds % 3600) / 60);
            const secs = seconds % 60;
            return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
        }

        updateCounter();
        if (!endTimeMs) {
            setInterval(updateCounter, 1000);
        }
    }
</script>
    
@endsection
