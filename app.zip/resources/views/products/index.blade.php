@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="create-btn float-end">

            <!-- Button trigger modal -->
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                Create
            </button>


        </div>

        <div class="table">
            <table class="table mt-3">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Quantity</th>
                        <th>Images</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="productTable">
                    <!-- Product rows will be populated by JavaScript -->
                    @foreach ($products as $product)
                        <tr>
                            <td>{{ $product->name }}</td>
                            <td>{{ $product->description }}</td>
                            <td>{{ $product->quantity }}</td>
                            <td>
                                @foreach ($product->images as $image)
                                    <img src="{{ $image->path }}" width="50" />
                                @endforeach
                            </td>
                            <td>
                                <button class="btn btn-info editBtn" data-value="{{ $product->id }}" data-toggle="modal"
                                    data-target="#editProduct">Edit</button>
                                <button class="btn btn-danger" onclick="deleteProduct($product->id)">Delete</button>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        <!-- Create Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Product Form</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="productForm">
                            <div class="mb-3">
                                <label for="name" class="form-label">Name</label>
                                <input type="name" class="form-control" id="name">

                            </div>
                            <div class="mb-3">
                                <label for="description" class="form-label">Description</label>
                                <textarea class="form-control" id="description" rows="3"></textarea>
                            </div>

                            <div class="mb-3">
                                <label for="quantity" class="form-label">Quantity</label>
                                <input type="number" class="form-control" id="quantity">

                            </div>
                            <div class="mb-3">
                                <label for="image" class="form-label">Quantity</label>
                                <input type="file" class="form-control" name="images[]" id="images" multiple>

                            </div>

                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>

                </div>
            </div>
        </div>

        {{-- Edit Modal --}}
        <div class="modal fade" id="editProduct" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Edit Product</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="editProductForm">

                            <input type="hidden" id="productId" name="productId">

                            <div class="mb-3">
                                <label for="name" class="form-label">Name</label>
                                <input type="name" class="form-control" id="editName">

                            </div>
                            <div class="mb-3">
                                <label for="description" class="form-label">Description</label>
                                <textarea class="form-control" id="editDescription" rows="3"></textarea>
                            </div>

                            <div class="mb-3">
                                <label for="quantity" class="form-label">Quantity</label>
                                <input type="number" class="form-control" id="editQuantity">

                            </div>
                            <div class="mb-3">
                                <label for="current-images" class="form-label">Current Images</label>
                                <div id="editImagePreview">

                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="update-image">Upload New Images</label>
                                <input type="file" name="images[]" id="newImages" multiple>
                            </div>

                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>

                </div>
            </div>
        </div>

    </div>
@endsection


@section('script')
    <script>
        $(document).ready(function() {
            function fetchProducts() {
                $.ajax({
                    url: '/',
                    method: 'GET',
                    success: function(products) {
                        console.log(products, 'datadata');
                        $('#productTable').html(''); // Clear the table
                        $.each(data, function(index, product) {

                        });
                    }
                });
            }
            $('#productForm').on('submit', function(e) {
                e.preventDefault();
                var formData = new FormData(this);
                formData.append('name', $('#name').val());
                formData.append('description', $('#description').val());
                formData.append('quantity', $('#quantity').val());

                $.ajax({
                    type: 'POST',
                    url: '/product/create',
                    contentType: false,
                    processData: false,
                    data: formData,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(result) {
                        console.log(result);
                        const product = result.data.product
                        const images = result.data.images
                        $('#productTable').append(`
                                <tr>
                                    <td>${product.name}</td>
                                    <td>${product.description}</td>
                                    <td>${product.quantity}</td>
                                    <td>${images.map(image => `<img src="${image.path}" width="50" />`).join('')}</td>
                                    <td>
                                        <button class="btn btn-info" onclick="editProduct(${product.id})">Edit</button>
                                        <button class="btn btn-danger" onclick="deleteProduct(${product.id})">Delete</button>
                                    </td>
                                </tr>
                            `);
                    },
                    error: function(err) {
                        console.log(err);
                    }
                })
            });
            $(document).on('click', '.editBtn', function() {
                const productId = $(this).data('value');
                $.ajax({
                    url: `/product/edit/${productId}`,
                    method: 'GET',
                    success: function(response) {
                        const product = response.data.product
                        const images = response.data.images
                        $('#editProduct').modal('show');
                        $('#editName').val(product.name);
                        $('#editDescription').val(product.description);
                        $('#editQuantity').val(product.quantity);
                        $('#productId').val(product.id);
                        $('#editImagePreview').html(images.map(image =>
                            `<img src="${image.path}" width="50" />`).join(''));
                    },
                    error: function(err) {
                        console.error('Failed to fetch product details', err);
                    }
                })
            });

            $('#editProductForm').on('submit', function(e) {
                e.preventDefault();
                var productId = $('#productId').val();
                var formData = new FormData(this);
                formData.append('name', $('#editName').val());
                formData.append('description', $('#editDescription').val());
                formData.append('quantity', $('#editQuantity').val());

                $.ajax({
                    type: 'POST',
                    url: `/product/edit/${productId}`,
                    contentType: false,
                    processData: false,
                    data: formData,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(result) {
                        console.log(result);
                        $('#editProduct').modal('hide');
                        const product = result.data.product
                        const images = result.data.images
                        $('#productTable').append(`
                                <tr>
                                    <td>${product.name}</td>
                                    <td>${product.description}</td>
                                    <td>${product.quantity}</td>
                                    <td>${images.map(image => `<img src="${image.path}" width="50" />`).join('')}</td>
                                    <td>
                                        <button class="btn btn-info" onclick="editProduct(${product.id})">Edit</button>
                                        <button class="btn btn-danger" onclick="deleteProduct(${product.id})">Delete</button>
                                    </td>
                                </tr>
                            `);
                    },
                    error: function(err) {
                        console.log(err);
                    }
                })
            });

        });
    </script>
@endsection
