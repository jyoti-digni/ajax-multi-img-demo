<?php

use App\Http\Controllers\DistanceController;
use App\Http\Controllers\HotelController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\SqlTestController;
use App\Http\Controllers\StripeController;
use App\Http\Controllers\WorkBreakController;
use App\Http\Controllers\WorkSessionController;
use App\Models\WorkSession;
use Illuminate\Support\Facades\Route;

// Route::get('/', function () {
//     return view('layouts.app');
// });



// Route::get('/', [ProductController::class, 'viewPage']);
Route::get('/', [ProductController::class, 'productView']);


Route::post('/product/create', [ProductController::class, 'productCreate']);
Route::get('/product/edit/{id}', [ProductController::class, 'productEdit']);
Route::post('/product/edit/{id}', [ProductController::class, 'productUpdate']);


Route::get('/hotel', [HotelController::class, 'viewHotel']);

Route::post('/hotel-store', [HotelController::class, 'storeHotel']);

Route::get('/hotel-view/{id}', [HotelController::class, 'viewHotelDetails']);


Route::get('checkout', [StripeController::class, 'checkout']);

Route::post('payment', [StripeController::class, 'handlePayment']);

Route::get('success', [StripeController::class, 'success']);


Route::get('/calculate-view', [DistanceController::class, 'calculateDistanceView']);

Route::get('/calculate-distance', [DistanceController::class, 'calculateDistance']);

Route::get('/sql', [SqlTestController::class, 'sqlTest']);

Route::get('/timer', [WorkSessionController::class, 'timerView']);
Route::post('/clock-in', [WorkSessionController::class, 'clockIn'])->name('clock.in');
Route::post('/clock-out', [WorkSessionController::class, 'clockOut'])->name('clock.out');
Route::post('/start-break', [WorkBreakController::class, 'startBreak'])->name('start.break');
Route::post('/end-break', [WorkBreakController::class, 'endBreak'])->name('end.break');
Route::get('/work-session-status', [WorkSessionController::class, 'getStatus']);





