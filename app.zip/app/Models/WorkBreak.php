<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WorkBreak extends Model
{
    use HasFactory;

    protected $guarded = [];

    public function workSession()
    {
        return $this->belongsTo(WorkSession::class);
    }

    // Method to calculate the break duration
    public function calculateBreakDuration()
    {
        if ($this->break_start && $this->break_end) {
            $breakStart = Carbon::parse($this->break_start);
            $breakEnd = Carbon::parse($this->break_end);
            return $breakEnd->diffInMinutes($breakStart) / 60; // Returns duration in hours
        }
        return 0;
    }

    // Update the break duration and end time
    public function endBreak()
    {
        $this->break_end = Carbon::now();
        $this->break_duration = $this->calculateBreakDuration();
        $this->save();
    }
}
