<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WorkSession extends Model
{
    use HasFactory;

    protected $guarded = [];



    // Define relationship to Break model
    public function breaks()
    {
        return $this->hasMany(WorkBreak::class);
    }


    public function getElapsedTimeAttribute()
    {
        if (!$this->end_time) {
            $end = now();
        } else {
            $end = $this->end_time;
        }

        $duration = $end->diffInSeconds($this->start_time);
        return $this->formatTime($duration);
    }

    private function formatTime($seconds)
    {
        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        $seconds = $seconds % 60;

        return sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);
    }
    // Get duration of time since clock-in
    public function getClockInDuration()
    {
        if ($this->clock_in) {
            return Carbon::now()->diffInSeconds(Carbon::parse($this->clock_in));
        }
        return 0;
    }

    // Get duration of time since break start
    public function getBreakDuration()
    {
        $activeBreak = $this->breaks()->whereNull('break_end')->first();
        if ($activeBreak) {
            return Carbon::now()->diffInSeconds(Carbon::parse($activeBreak->break_start));
        }
        return 0;
    }
}
