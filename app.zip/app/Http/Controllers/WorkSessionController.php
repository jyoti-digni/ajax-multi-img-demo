<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\WorkSession;
use Carbon\Carbon;
use Auth;

class WorkSessionController extends Controller
{
    public function timerView()
    {
        $workSessions = WorkSession::with('breaks')->get();
        // dd($workSessions);
        return view('work-session', compact('workSessions'));
    }

    public function index()
    {
        $timeEntries = WorkSession::where('user_id', Auth::id())->get();
        return view('time_entries.index', compact('timeEntries'));
    }

    public function start()
    {
        $timeEntry = new WorkSession();;
        $timeEntry->start_time = now();
        $timeEntry->save();

        return redirect()->route('time_entries.index');
    }

    public function stop($id)
    {
        $timeEntry = WorkSession::findOrFail($id);
        $timeEntry->end_time = now();
        $timeEntry->save();

        return redirect()->route('time_entries.index');
    }
    public function clockIn()
    {
        $existingSession = WorkSession::whereNull('clock_out')  // Check if already clocked in
            ->first();

        if ($existingSession) {
            return response()->json(['error' => 'You are already clocked in.'], 400);
        }

        WorkSession::create([

            'clock_in' => Carbon::now(),
        ]);

        return response()->json(['success' => 'Clocked in successfully.']);
    }

    // Clock out the user
    public function clockOut()
    {
        $workSession = WorkSession::whereNull('clock_out')  // Find active session
            ->first();

        if (!$workSession) {
            return response()->json(['error' => 'You are not clocked in.'], 400);
        }

        // Calculate total working hours excluding break time
        $clockOutTime = Carbon::now();
        $totalWorkingHours = $clockOutTime->diffInMinutes($workSession->clock_in) / 60;

        $workSession->update([
            'clock_out' => $clockOutTime,
            'total_working_hours' => $totalWorkingHours - $workSession->total_break_time, // Subtract breaks
        ]);

        return response()->json(['success' => 'Clocked out successfully.']);
    }
    public function getStatus()
    {
        $workSession = WorkSession::whereNull('clock_out')
            ->first();

        if ($workSession) {
            return response()->json([
                'clockInDuration' => $workSession->getClockInDuration(),
                'breakDuration' => $workSession->getBreakDuration()
            ]);
        }

        return response()->json([
            'clockInDuration' => 0,
            'breakDuration' => 0
        ]);
    }
}
