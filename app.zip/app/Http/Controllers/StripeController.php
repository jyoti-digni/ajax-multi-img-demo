<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Stripe\Charge;
use Stripe\PaymentIntent;
use Stripe\Stripe;

class StripeController extends Controller
{
    public function checkout()
    {
        return view('strips.index');
    }

    public function handlePayment(Request $request)
    {
        Stripe::setApiKey(config('services.stripe.secret'));

        // Create the PaymentIntent with the amount and payment method
        $paymentIntent = PaymentIntent::create([
            'amount' => 5000, // Amount in cents ($50.00)
            'currency' => 'usd',
            'payment_method' => $request->payment_method_id,
            'confirmation_method' => 'manual',
            'confirm' => true, // Confirm the payment immediately
            'automatic_payment_methods' => [
                'enabled' => true,
                'allow_redirects' => 'never' // Disable redirect-based payment methods
            ],
        ]);

        // Return the client_secret so the frontend can complete the payment
        return response()->json(['client_secret' => $paymentIntent->client_secret]);

        // try {
        //     Charge::create([
        //         'amount' => $request->amount * 100,
        //         'currency' => 'usd',
        //         'source' => $request->stripeToken,
        //         'description' => 'Test Payment',
        //     ]);

        //     return redirect()->back()->with('success', 'Payment Successfull');
        // } catch (\Exception $e) {

        //     return redirect()->back()->with('error', $e->getMessage());
        // }
    }

    public function success()
    {
        return view('strips.success');
    }
}
