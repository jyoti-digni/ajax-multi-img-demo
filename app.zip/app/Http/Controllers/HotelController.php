<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Hotel;
use GuzzleHttp\Client;
use Illuminate\Http\Request;

class HotelController extends Controller
{
    public function viewHotel()
    {
        $hotels = Hotel::with('locations')->get();

        foreach ($hotels as $hotel) {
            foreach ($hotel->locations as $location) {
                $location->address = $this->getAddressFromLatLng($location->latitude, $location->longitude);
            }
        }
        return view('hotels.index', compact('hotels'));
    }

    public function storeHotel(Request $request)
    {
        $hotel = Hotel::create([
            'name' => $request->name,
            'description' => $request->description,
        ]);
        if ($request->has('locations')) {
            foreach ($request->locations as $location) {
                $hotel->locations()->create([
                    'hotel_id' => $hotel->id,
                    'latitude' => $location['latitude'],
                    'longitude' => $location['longitude']
                ]);
            }
        }


        return response()->json(
            [
                'success' => 'Hotel created successfully',
                'data' => [
                    'hotel' => $hotel,
                    'locations' => $hotel->locations
                ]
            ]
        );
    }


    public function getAddressFromLatLng($latitude, $longitude)
    {
        $client = new Client();
        $apiKey = '5350d5e7904042abb3ff03218fe8b8cc';

        // Build the OpenCage API request URL
        $url = "https://api.opencagedata.com/geocode/v1/json?q={$latitude}+{$longitude}&key={$apiKey}";

        try {
            // Make the request to OpenCage API
            $response = $client->get($url);
            $data = json_decode($response->getBody());

            // Check if the API returned a valid result
            if (isset($data->results[0])) {
                return $data->results[0]->formatted; // Return the formatted address
            }

            return 'Address not found';
        } catch (\Exception $e) {
            // Handle the error
            return 'An error occurred: ' . $e->getMessage();
        }
    }


    public function viewHotelDetails($id)
    {
        $hotel = Hotel::with('locations')->findOrFail($id);

        foreach ($hotel->locations as $location) {
            $location->address = $this->getAddressFromLatLng($location->latitude, $location->longitude);
        }
    

        return view('hotels.view', compact('hotel'));
    }
}
