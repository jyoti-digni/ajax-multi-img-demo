<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\WorkSession;
use App\Models\Break;
use App\Models\WorkBreak;
use Carbon\Carbon;


class WorkBreakController extends Controller
{
    // Start a break
    public function startBreak()
    {
        $workSession = WorkSession::
whereNull('clock_out')
                                  ->first();

        if (!$workSession) {
            return response()->json(['error' => 'You are not clocked in.'], 400);
        }

        // Check if a break is already in progress
        $activeBreak = WorkBreak::where('work_session_id', $workSession->id)
                            ->whereNull('break_end')
                            ->first();

        if ($activeBreak) {
            return response()->json(['error' => 'You are already on a break.'], 400);
        }

        WorkBreak::create([
            'work_session_id' => $workSession->id,
            'break_start' => Carbon::now(),
        ]);

        return response()->json(['success' => 'Break started successfully.']);
    }

    // End a break
    public function endBreak()
    {
        $workSession = WorkSession::whereNull('clock_out')
                                  ->first();

        if (!$workSession) {
            return response()->json(['error' => 'You are not clocked in.'], 400);
        }

        // Find the ongoing break
        $activeBreak = WorkBreak::where('work_session_id', $workSession->id)
                            ->whereNull('break_end')
                            ->first();

        if (!$activeBreak) {
            return response()->json(['error' => 'No active break found.'], 400);
        }

        // Calculate break duration
        $breakEndTime = Carbon::now();
        $breakDuration = $breakEndTime->diffInMinutes($activeBreak->break_start) / 60;  // in hours

        // Update the break session
        $activeBreak->update([
            'break_end' => $breakEndTime,
            'break_duration' => $breakDuration,
        ]);

        // Add to total break time in the work session
        $workSession->increment('total_break_time', $breakDuration);

        return response()->json(['success' => 'Break ended successfully.']);
    }
}

