<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Image;
use App\Models\Log;
use App\Models\Product;
use GrahamCampbell\ResultType\Success;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class ProductController extends Controller
{
    public function productView()
    {
        $products = Product::with('images')->get();
        return view('products.index', compact('products'));
    }

    public function productCreate(Request $request)
    {
        $product = Product::create([
            'name' => $request->name,
            'description' => $request->description,
            'quantity' => $request->quantity
        ]);

        if ($request->has('images')) {
            foreach ($request->images as $image) {
                $filename = $image->store('images');
                Image::create([
                    'product_id' => $product->id,
                    'path' => $filename
                ]);
            }
        }
        Log::create([
            'message' => 'product created',
            'type' => 'Product'
        ]);
        return response()->json([
            'message' => 'product created',
            'data' => [
                'product' => $product,
                'images' => $product->images
            ],
            'status' => Response::HTTP_OK
        ]);
    }

    public function productEdit($id)
    {
        $product = Product::with('images')->findOrFail($id);
        return response()->json([
            'data' => [
                'product' => $product,
                'images' => $product->images
            ]
        ]);
    }

    public function productUpdate(Request $request, $id)
    {
        $product = Product::findOrFail($id);

        $product->update([
            'name' => $request->name,
            'description' => $request->description,
            'quantity' => $request->quantity
        ]);

        if ($request->has('images')) {
            Image::whereIn('id', $request->images)->delete();
        }
        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $image) {
                $filename = $image->store('images');
                Image::create([
                    'product_id' => $product->id,
                    'path' => $filename
                ]);
            }
        }

        Log::create([
            'message' => 'product updated',
            'type' => 'Product'
        ]);
        return response()->json([
            'message' => 'product updated',
            'data' => [
                'product' => $product,
                'images' => $product->images
            ],
            'status' => Response::HTTP_OK
        ]);
    }
}
