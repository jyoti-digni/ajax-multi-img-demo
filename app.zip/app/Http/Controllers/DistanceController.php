<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Services\DistanceService;
use Illuminate\Http\Request;
use OpenCage\Geocoder\Geocoder;

class DistanceController extends Controller
{
    protected $distanceService;

    public function __construct(DistanceService $distanceService)
    {
        $this->distanceService  = $distanceService;
    }

    public function calculateDistanceView()
    {
        return view('calculates.index');
    }

    public function calculateDistance(Request $request)
    {

        $request->validate([
            'origin' => 'required|string',
            'destination' => 'required|string'
        ]);

        $origin = $request->input('origin');
        $destination = $request->input('destination');

        // Step 1: Geocode the origin and destination using OpenCage
        $geocoder = new Geocoder(env('OPENCAGE_API_KEY')); // Replace with your OpenCage API key
        // Geocode the origin
        $originResult = $geocoder->geocode($origin);
        if (empty($originResult['results'])) {
            return response()->json(['error' => 'Invalid origin location'], 400);
        }
        $originCoordinates = [
            'lat' => $originResult['results'][0]['geometry']['lat'],
            'lng' => $originResult['results'][0]['geometry']['lng']
        ];

        // Geocode the destination
        $destinationResult = $geocoder->geocode($destination);
        if (empty($destinationResult['results'])) {
            return response()->json(['error' => 'Invalid destination location'], 400);
        }
        $destinationCoordinates = [
            'lat' => $destinationResult['results'][0]['geometry']['lat'],
            'lng' => $destinationResult['results'][0]['geometry']['lng']
        ];

        // Step 2: Calculate the distance using OpenRouteService
        $distanceData = $this->distanceService->calculateDistance($originCoordinates, $destinationCoordinates);

        return view('calculates.index', ['distanceData' => $distanceData]);
    }
}
