<?php

namespace App\Services;

use GuzzleHttp\Client;

class DistanceService
{
    protected $client;
    protected $apikey;

    public function __construct()
    {
        $this->client = new Client();
        $this->apikey = config('services.openrouteservice.api_key');
    }

    public function calculateDistance($origin, $destination)
    {
        $url = 'https://api.openrouteservice.org/v2/matrix/driving-car';

        $params = [
            'locations' => [
                [$origin['lng'], $origin['lat']],   // Longitude and Latitude for origin
                [$destination['lng'], $destination['lat']] // Longitude and Latitude for destination
            ],
            'metrics' => ['distance', 'duration'],
            'units' => 'km',
        ];
        try {
            $response = $this->client->post($url, [
                'headers' => [
                    'Authorization' => $this->apikey,
                    'Content-Type' => 'application/json',
                ],
                'json' => $params
            ]);

            $data = json_decode($response->getBody(), true);
            if (isset($data['distances']) && isset($data['durations'])) {
                return [
                    'distance' => $data['distances'][0][1],   // Distance between the two points
                    'duration' => $data['durations'][0][1] / 60, // Duration in minutes
                ];
            }
            return [
                'distance' => null,
                'duration' => 0,
            ];

        } catch (\Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
}
