<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="nav-link">
        <a class="navbar-brand" href="#">Laravel</a>
        <a class="navbar-brand" href="<?php echo e(url('/hotel')); ?>">Hotel</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

    </div>
</nav>
<?php /**PATH D:\xampp-versions\xampp\htdocs\ajax-demo\resources\views/layouts/header.blade.php ENDPATH**/ ?>